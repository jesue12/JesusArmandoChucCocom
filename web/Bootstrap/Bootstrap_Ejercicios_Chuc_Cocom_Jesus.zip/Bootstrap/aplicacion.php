<!DOCTYPE html>
    <title>Mi Página de Bienvenida</title>
</head>
<body>

<h2 id="bienvenida">Bienvenido</h2>
<p>¡Bienvenido a mi página! 
