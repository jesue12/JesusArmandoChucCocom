<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include_once 'propel_init_loader.php';

$usu = $_POST["txtUsuario"];
$con = $_POST["txtContrasena"];
/*-----------------------------------*/

$dat = DatosQuery::create()->filterByCorreo($usu)->findOne();
/*-----------------------------------*/
if($dat->getContrasena()==$con)
  {
    //echo "Bienvenido";
    $_SESSION["usuario"] = $usu;
    header('location: aplicacion.php');

 }
 
  else
 {
    //echo "Credenciales incorrectas";
      header('location: index.php?valor=error1');
 }

