<div class="container text-center">
  <div class="row">
    <div class="col">
      Logo
    </div>
    <div class="col">
      Acerca de
    </div>
    <div class="col">
      Copyright 2024
    </div>
  </div>
</div>

