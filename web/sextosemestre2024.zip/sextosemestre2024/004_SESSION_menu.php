<a href="003_SESSION_aplicacion.php">INICIO</a> | 
<a href="003_SESSION_aplicacion.php?pagina=estudiantes">ESTUDIANTES</a> | 
<a href="003_SESSION_aplicacion.php?pagina=materias">MATERIAS</a> | 
<a href="003_SESSION_aplicacion.php?pagina=carreras">CARRERAS</a> | 
<a href="003_SESSION_aplicacion.php?pagina=modalidades">MODALIDADES</a> | 
<a href="003_SESSION_login.php?valor=cerrar">CERRAR</a>